<?php
class ZTSoftware_MagePDV_Model_Api extends Mage_Api_Model_Resource_Abstract
{        
		public function productList()
        {
        	$retArray = array();
        	$products = Mage::getModel('catalog/product')->getCollection()
        	 				->addAttributeToSelect('*');

        	foreach ($products as $product) {
        		$retArrayTmp = array(
		                "product_id" => $product->getId(),
		                "sku" => $product->getSku(),
		                "name" => $product->getName(),
		                "price" => $product->getPrice(),
		                "stock" => $product->getStockItem()->getQty(),
		                "image1" => $product->getImageUrl(),
		                "image2" => $product->getImageUrl()
        			);

        		array_push($retArray, $retArrayTmp);
        	}

        	return $retArray;

        }        
		public function customerList()
        {
        }
}