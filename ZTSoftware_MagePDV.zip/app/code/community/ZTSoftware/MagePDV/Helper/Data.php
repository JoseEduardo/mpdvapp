<?php
class ZTSoftware_MagePDV_Helper_Data extends Mage_Core_Helper_Abstract
{
}
	 