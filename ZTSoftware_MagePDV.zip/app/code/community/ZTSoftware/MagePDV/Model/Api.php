<?php
class ZTSoftware_MagePDV_Model_Api extends Mage_Api_Model_Resource_Abstract
{        
		public function productList()
        {
        }        
		public function customerList()
        {
        }
}